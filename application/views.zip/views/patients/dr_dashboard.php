 <script type="text/javascript">
 setInterval(function(){ location.reload() }, 300000);

   $(document).ready(function(){

         $('.country').change(function()
                    {
                               
                             
                               var country=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!country)) {alert("Please Select Country ")}
                              else{
                           //alert(country);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_stateByCountryId',
                                    method:'get',
                                    data:{country:country},

                                    success:function(state)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#statelist').html(state);
                                        $('#district_list').html('<option>Select District</option>');
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(state)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })


                  $('.state').change(function()
                    {
                               
                             
                               var state=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!state)) {alert("Please Select State ")}
                              else{
                        //   alert(state);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_districtByStateId',
                                    method:'get',
                                    data:{state:state},

                                    success:function(district)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#district_list').html(district);
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(district)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })
                   $('.district').change(function()
                    {
                               
                             
                               var dist=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!dist)) {alert("Please Select State ")}
                              else{
                           //alert(state);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_cityByDistrict',
                                    method:'get',
                                    data:{dist:dist},

                                    success:function(district)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#city_list').html(district);
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(district)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })



                    $('.comp_country1').change(function()
                    {
                               
                             
                               var comp_country1=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!comp_country1)) {alert("Please Select Country ")}
                              else{
                           //alert(comp_country1);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_stateByCountryId',
                                    method:'get',
                                    data:{country:comp_country1},

                                    success:function(comp_state1)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#comp_statelist1').html(comp_state1);
                                        $('#comp_district_list1').html('<option>Select District</option>');
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(comp_state1)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })



                    $('.comp_state1').change(function()
                    {
                               
                             
                               var comp_state1=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!comp_state1)) {alert("Please Select State ")}
                              else{
                         //  alert(comp_state1);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_districtByStateId',
                                    method:'get',
                                    data:{state:comp_state1},

                                    success:function(district)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#comp_district_list1').html(district);
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(district)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })


                        $('.comp_district1').change(function()
                    {
                               
                             
                               var dist=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!dist)) {alert("Please Select State ")}
                              else{
                           //alert(state);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_cityByDistrict',
                                    method:'get',
                                    data:{dist:dist},

                                    success:function(district)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#comp_city_list1').html(district);
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(district)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })






                          $('.comp_country2').change(function()
                    {
                               
                             
                               var comp_country2=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!comp_country2)) {alert("Please Select Country ")}
                              else{
                           //alert(comp_country1);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_stateByCountryId',
                                    method:'get',
                                    data:{country:comp_country2},

                                    success:function(comp_state2)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#comp_statelist2').html(comp_state2);
                                        $('#comp_district_list2').html('<option>Select District</option>');
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(comp_state2)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })



                    $('.comp_state2').change(function()
                    {
                               
                             
                               var comp_state2=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!comp_state2)) {alert("Please Select State ")}
                              else{
                        //   alert(comp_state2);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_districtByStateId',
                                    method:'get',
                                    data:{state:comp_state2},

                                    success:function(district)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#comp_district_list2').html(district);
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(district)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })


                        $('.comp_district2').change(function()
                    {
                               
                             
                               var dist=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!dist)) {alert("Please Select State ")}
                              else{
                           //alert(state);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_cityByDistrict',
                                    method:'get',
                                    data:{dist:dist},

                                    success:function(district)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#comp_city_list2').html(district);
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(district)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })


                        $('.rangesize1').mouseleave(function(){


                           
                              var l=$(this).val();
                              if (l.length>25)
                               {
                                return alert("Range label should be less than 25 Character");
                                  }
                                   

                        })



                          $('.rangesize2').mouseleave(function(){


                           
                              var l=$(this).val();
                              if (l.length>25)
                               {
                                return alert("Range label should be less than 25 Character");
                                  }
                                   

                        })
                $('.city').change(function()
                    {
                               
                             
                               var city=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!city)) {alert("Please Select City ")}
                              else{
                           //alert(state);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_pincodeByCity',
                                    method:'get',
                                    data:{city:city},

                                    success:function(pincode)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#pincode_list').html(pincode);
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(pincode)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })


                     $('.city1').change(function()
                    {
                               
                             
                               var city=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!city)) {alert("Please Select City ")}
                              else{
                           //alert(state);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_pincodeByCity',
                                    method:'get',
                                    data:{city:city},

                                    success:function(pincode)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#pincode_list1').html(pincode);
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(pincode)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })
                       $('.city2').change(function()
                    {
                               
                             
                               var city=$(this).val();
                              
                             // var dname=$(this).attr('dept');
                             if ((!city)) {alert("Please Select City ")}
                              else{
                           //alert(state);
                              

                               $.ajax({

                                    url:'<?= base_url() ?>users/get_pincodeByCity',
                                    method:'get',
                                    data:{city:city},

                                    success:function(pincode)
                                    {
                                      //  alert(dept);
                                           // id='#'+show;
                                        $('#pincode_list2').html(pincode);
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(pincode)
                                    {
                                        alert('error occurs');
                                    }


                        })
                           } 


                        })

       })

</script>
  <style type="text/css">
      /* Full height */
  .bg{height:50%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

  </style>
 
  <div class="clearfix" style="height:5%">
      
  </div>
   <section  id="task_board">
        <div class="container">
            <div class="col-12 titl_card">
                <h3>patient  <?= $ptdata['heading']?>  <?= !empty($this->session->userdata('statename'))?$this->session->userdata('statename'):'' ?> Dashboard</h3>
            </div>

                <div style="height:50px"></div>
            <p><?php if(!empty($zoneDetails)){echo$zoneDetails; } else {?></p>
 
 <div class="pull-right"><button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">Change</button>
</div><?php } ?>
            <div class="row third_cls" id="dashboard">
                <div class="col-md-4 col-lg-4 col-sm-6 left_bg">
                    <img class="bg"  style="height:10%;" src="<?= base_url('assets/dashboard').'/'?>hexagon.png" />
                    <div class="left_bg_div">
                        <h5>Total <?= $ptdata['heading'] ?></h5>
                       <h2><?=  (int)$ptdata['total'] ?></h2>
                       
                                            <!--Growth calculation Data clsoe Here-->
                      
                      
                    </div>
                </div>
                <div class="col-md-12 col-lg-8 third_innr_crcl" style="float:all;">
                    <div class="row" style="justify-content: space-between;">
                        <div class="col-md-3 col-lg-3 col-sm-6 cmn_cls marg_btm_cls" style="background-color:rgb(200,250,100);color:black;">
                           
                                 <a href="<?= base_url('patient_registers/patient_list/yesterdaylist/'.$ptdata['link']) ?>"><span><b>Yesterday</b></span></a>
                           <h2><?= (int)$ptdata['yesterday'] ?></h2>
                            
                            
                        </div>
                        <div class="col-sm-1"></div>
                        <div class="col-md-3 col-lg-3 col-sm-6 cmn_cls org marg_btm_cls" style="background-color:rgb(250,200,150);color:black;">
                             <a href="<?= base_url('patient_registers/patient_list/todaylist/'.$ptdata['link']) ?>"><span><b>Today</b></span></a>
                            <h2><?= (int)$ptdata['today'] ?></h2>
                             
                        </div>
                        
                        <div class="col-sm-1"></div>
                        <div class="col-md-3 col-lg-3 col-sm-6 cmn_cls org marg_btm_cls" style="background-color:rgb(250,200,150);color:black;">
                             <a href="<?= base_url('patient_registers/patient_list/weeklist/'.$ptdata['link']) ?>"><span><b>This Week</b></span></a>
                            <h2><?= (int)$ptdata['week'] ?></h2>
                             
                        </div>
        
                    </div>
                    <br>
                    <br>
                    <div class="row" style="justify-content: space-between;">
                        <div class="col-md-3 col-lg-3 col-sm-6 cmn_cls marg_btm_cls" style="background-color:rgb(200,250,100);color:black;">
                           
                                 <a href="<?= base_url('patient_registers/patient_list/fortnightlist/'.$ptdata['link']) ?>"><span><b>This Fortnight</b></span></a>
                           <h2><?= (int)$ptdata['fortnight'] ?></h2>
                            
                            
                        </div>
                        <div class="col-sm-1"></div>
                        <div class="col-md-3 col-lg-3 col-sm-6 cmn_cls org marg_btm_cls" style="background-color:rgb(250,200,150);color:black;">
                             <a href="<?= base_url('patient_registers/patient_list/monthlist/'.$ptdata['link']) ?>"><span><b>This Month</b></span></a>
                            <h2><?= (int)$ptdata['month'] ?></h2>
                             
                        </div>
                        
                        <div class="col-sm-1"></div>
                        <div class="col-md-3 col-lg-3 col-sm-6 cmn_cls org marg_btm_cls" style="background-color:rgb(250,200,150);color:black;">
                             <a href="<?= base_url('patient_registers/patient_list/yearlist/'.$ptdata['link']) ?>"><span><b>This Year</b></span></a>
                            <h2><?= (int)$ptdata['year'] ?></h2>
                             
                        </div>
        
                    </div>
                    

                </div>
            </div>
            <br>
                                        <div class="col-sm-12 col-md-3 col-lg-3" >
                                <h4><a href="javascript:void()" class="btn btn info blu"  onclick="location.reload()">Refresh</a></h4>
                            </div>
                        <div class="col-sm-12 col-md-3 col-lg-3">
                              <?php if(empty($status)){  if(empty($today)){ ?><a class="btn btn info blu" href="<?= base_url('dashboard/view_haspatal_dashboard/today') ?>">Today's Data</a><?php } else{ ?><a class="btn btn info blu" href="<?= base_url('dashboard/view_haspatal_dashboard') ?>">Total Data</a><?php }
                              }
                              ?>
                              
                              
                              
                              <?php if(!empty($status)){  if(empty($today)){ ?><a class="btn btn info blu" href="<?= base_url('dashboard/view_haspatal_dashboard/all') ?>">Total Data</a><?php } else{ ?><a class="btn btn info blu" href="<?= base_url('dashboard/view_haspatal_dashboard') ?>">Today's Data</a><?php }
                              }
                              ?>
                            </div>
                            <?php  if($this->session->userdata('user_role')!=19){ ?>
                         <div class="col-sm-12 col-md-3 col-lg-3">
                               <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-compare-modal-lg">Compare</button>
                            </div><?php } ?>
                            
                            <div class="col-sm-12 col-md-3 col-lg-3">
                                <a class="btn btn info blu" href="#">Chart</a>
                            </div>
                            
                            
        </div>
    </section>
    
    
    
                  
    
    
    
    
    
    
    
    
    
    
    
   <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">

    <div class="modal-content">
      <div class="modal-header" style="background-color:#323200;color:white">
        <h5 class="modal-title" id="exampleModalLabel">Program <?= var_dump($st) ?> dashboard</h5>
        <button type="button" class="close" style="background-color:white;" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="container-fluid">
        <form class="form-group" method="post" action="<?=base_url('dashboard/filter_byRange_dashboard')?>">
           <div class="row">
               <h3><b></b>Change Dashboard Data Range</b></h3>
           </div>
            <div class="row">
                <div class="col-sm-6">
                <label>Start Date</label>
                <input type="date" class="from-control" name="start_date">
            </div>
            <div class="col-sm-6">
                <label>End Date</label>
                <input type="date" class="from-control" name="end_date">
            </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-md-3">
                    <select name="country" class="form-control country">
                        <option>Select Country</option>
                        <option value="3" selected>India</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="state" <?= $st?"":"disabled=''"; ?> class="form-control state" id="statelist">
                        <option>Select State</option>
                        <?php
                     echo $s=$st?" ":"<option value='$stateData->id' selected>$stateData->state</option>";
                            foreach ($full_list as $key => $value) {
                          ?>
                          <option value="<?=$value->id ?>"><?= $value->state ?></option>
                          <?php
                            }
                        ?>
                    </select>
                </div><div class="col-md-3">
                    <select name="district" <?= $dis?"":"disabled=''"; ?> class="form-control district" id="district_list">
                      <?php  
                            echo $s=$dis?" ":"<option value='$districtData->id' selected>$districtData->district_name</option>";
                          ?>
                           <?php
                        if(!empty($dlist))
                        {
                        foreach ($dlist as $value) {
                      ?>
                        <option value="<?= $value->id ?>"><?= $value->district_name ?></option>
                      <?php } }?>
                    </select>
                </div><div class="col-md-3">
                    <select name="city" <?= $dis?"":"disabled=''"; ?> class="form-control city" id="city_list">
                        <option>Select City</option>
                        <?php
                        echo $s=$cit?" ":"<option value='$cityData->id' selected>$cityData->city</option>";
                        if(!empty($clist))
                        {
                        foreach ($clist as $value) {
                      ?>
                        <option value="<?= $value->id ?>"><?= $value->city ?></option>
                      <?php } }?>
                    </select>
                </div>
            </div>
            <br>
            <div class="row">
                <?php  if($this->session->userdata('user_role')==19) { ?>
                <div class="col-md-3">
                    <select name="city_zone" class="form-control" id="cz_list">
                        <option>Select City Zone</option>
                        <?php if(!empty($czlist))
                        {
                        foreach ($czlist as $value) {
                      ?>
                        <option value="<?= $value->id ?>"><?= $value->city_zone ?></option>
                      <?php } }?>
                    </select>
                </div>
                <?php } ?>
                <div class="col-md-3">
                    <select name="pincode" class="form-control" id="pincode_list">
                        <option>Select Pincode</option>
                        <?php  if(!empty($plist))
                        {
                        foreach ($plist as $value) {
                      ?>
                        <option value="<?= $value->id ?>"><?= $value->pincode ?></option>
                      <?php } }?>
                    </select>
                </div>
            <div class="col-md-6">
                <input class="btn btn-info" style="color:white;background-color:#323200;border-color:#323200" type="submit" name="submit">
            </div>
        </div>
        </form>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>



<!--    Compare Data -->

 <div class="modal fade bd-compare-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">

    <div class="modal-content">
      <div class="modal-header" style="background-color:#323200;color:white">
        <h5 class="modal-title" id="exampleModalLabel">Program dashboard</h5>
        <button type="button" class="close" style="background-color:white;" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="container-fluid">
        <form class="form-group" method="post" action="<?= base_url('dashboard/compare_byRange_dashboard')?>">
           <div class="row">
               <h3><b>Change Dashboard Data Range</b></h3>
           </div>
           <br>
           <div class="row">
            <div class="col-md-3"> <label>Base Range Label</label></div>
            <div class="col-md-9">
              <div class="form-group">
                  <input type="text" name="range_label1" class="form-control rangesize1">
             </div>
           </div>
            <div class="row">
                <div class="col-sm-6">
                <label>Start Date</label>
                <input type="date" class="from-control" name="start_date1">
            </div>
            <div class="col-sm-6">
                <label>End Date</label>
                <input type="date" class="from-control" name="end_date1">
            </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-md-2">
                    <select name="comp_country1" class="form-control comp_country1">
                        <option>Select Country</option>
                        <option value="3">India</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="comp_state1" class="form-control comp_state1" id="comp_statelist1">
                        <option>Select State</option>
                        
                    </select>
                </div><div class="col-md-3">
                    <select name="comp_district1" class="form-control comp_district1" id="comp_district_list1">
                      <?php  

                          foreach ($dlist as $value) {
                      ?>
                        <option value="<?= $value ?>"><?= $value ?></option>
                      <?php } ?>
                    </select>
                </div><div class="col-md-2">
                    <select name="comp_city1" class="form-control city1" id="comp_city_list1">
                        <option>Select City</option>
                    </select>
                </div>
            
            
            
                <div class="col-md-2">
                    <select name="comp_pincode1" class="form-control" id="pincode_list1">
                        <option>Select Pincode</option>
                       
                    </select>
                </div>

</div>
    <hr style="color:black;height:10%;">

                 <br>
           <div class="row">
            <div class="col-md-3"> <label>Compare Range Label </label></div>
            <div class="col-md-9">
              <div class="form-group">
                  <input type="text" name="range_label2" class="form-control rangesize2">
             </div>
           </div>
            <div class="row">
                <div class="col-sm-6">
                <label>Start Date</label>
                <input type="date" class="from-control" name="start_date2">
            </div>
            <div class="col-sm-6">
                <label>End Date</label>
                <input type="date" class="from-control" name="end_date2">
            </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-md-2">
                    <select name="comp_country2" class="form-control comp_country2">
                        <option>Select Country</option>
                        <option value="3">India</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="comp_state2" class="form-control comp_state2" id="comp_statelist2">
                        <option>Select State</option>
                        
                    </select>
                </div><div class="col-md-3">
                    <select name="comp_district2" class="form-control comp_district2" id="comp_district_list2">
                      <?php  

                          foreach ($dlist as $value) {
                      ?>
                        <option value="<?= $value ?>"><?= $value ?></option>
                      <?php } ?>
                    </select>
                </div><div class="col-md-2">
                    <select name="comp_city2" class="form-control city2" id="comp_city_list2">
                        <option>Select City</option>
                    </select>
                </div>
            
            
            
                <div class="col-md-2">
                    <select name="comp_pincode2" class="form-control" id="pincode_list2">
                        <option>Select Pincode</option>
                        
                    </select>
                </div>
              </div>
              <br>
            <div class="text-center">
                <input class="btn btn-info" style="color:white;background-color:#323200;border-color:#323200" type="submit" name="submit">
            </div>
        </div>
        </form>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
