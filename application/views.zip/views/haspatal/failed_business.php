<br>
<br>
<br>
<br>
<br>
<div class="container">
    
    <div class="alert alert-danger text-center">
        <h6> Business Registeration failed </h6>
        <a class="btn btn-info" href="<?= base_url('haspatal_registers/business_register') ?>">Go Back</a>
    </div>
</div>