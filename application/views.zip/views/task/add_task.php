
<div style="padding: 2%">
	<div class="row">
		<div class="col-lg-12" style="">
			<h1 class="page-header">Tasks</h1>
		</div>
		<!-- /.col-lg-12 -->
	</div>
	<!-- /.row -->
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading" style="background-color:#323200;border-color:#323200;color:white;">
					<strong>Add Task</strong>	
					<strong class="pull-right"><font color="red">* </font>Fields Required</strong>
				</div>
				<div class="panel-body" >
					<div class="row">
						<div class="col-lg-12">
								

						<?php 
							$this->load->view('common/errors');
						?>
							<form role="form" name="editprofileform" id="editprofileform" method="post" action="do_save" enctype="multipart/form-data">
							<div class="form-group">
									<label>Program:<strong><font color='red'>*</font></strong></label>
									<select class="form-control" name="program">
											
											<?php
											foreach ($program as $value) {
										?>
											<option value="<?=$value->pid ?>"><?=$value->pro_name ?></option>


										<?php
											}


											?>


									</select>
								</div>
								<div class="form-group" >
									<select class="	form-control" multiple="">
										<option value="	hii">Hi</option>
										<option value="	hii">Hi</option>
										<option value="	hii">Hi</option>
									</select> 
								</div>

           						           						<br>	
           						<div class="form-group">
           							<button class="btn btn-info test">hii</button>
<input type="submit" name="submit" class="btn btn-info " style="color:white;background-color: #323200;border-color: #323200">
           						</div>
							</form>
						</div>     
					</div>
                    <!-- /.row (nested) -->
				</div>
                <!-- /.panel-body -->
			</div>
			<!-- /.panel -->
		</div>
		<!-- /.col-lg-12 -->
	</div>
	<!-- /.row -->
	</div>
	<!-- /#page-wrapper -->
</div>
</div>