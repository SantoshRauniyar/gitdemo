		<script type="text/javascript">
			
 
$(document).ready(function(){






                 //check all order by OID
                               $('.assign').click(function()
                    {
                       
                                let task_id =$(this).attr('tid');
                                console.log(task_id);
                                $('#heading').html(task_id+' Haspatal Register');
                                $('#tid').val(task_id);

        /*
                        $.ajax({

                                    url:'<?= base_url() ?>users/getusers',
                                    method:'get',
                                    data:{uid:id,did:uid},

                                    success:function(unithead)
                                    {
                                        //alert(unithead);
                                           // id='#'+show;
                                        $('#my').html(unithead);
                                        // $('.mycartCount').click();
                                         
                                         
                                    },
                                   error:function(unithead)
                                    {
                                        alert('error occurs');
                                    }


                        })*/
                    })

})
</script>
<div style="padding:2%;">
	<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">Tasks</h1>
		</div>
		<!-- /.col-lg-12 -->
	</div>
	<!-- /.row -->
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading" style="background-color: #323200;border-color:#323200;color:white;vertical-align:all;">
					<strong>Unit Taskboard</strong>
					<div class="row text-right">
						<div class="container pull-right" ><div class="col-md-4"></div><div class="col-md-2"><a href="#" style="color:yellow;text-decoration: none;font-weight: bold;" id="noti"><h4>Today</h4></a></div><div class="col-md-2"><a href="" style="color:white;text-decoration: none;font-weight: bold;" id="noti" onMouseOver="this.style.color='yellow'" onMouseLeave="this.style.color='#fff'"><h4>Tomorrow</h4></a></div><div class="col-md-2"><a onMouseOver="this.style.color='yellow'" onMouseLeave="this.style.color='#fff'" href="#" style="color:white;text-decoration: none;font-weight: bold;" id="noti"><h4>This Week</h4></a></div><div class="col-md-2"><a onMouseOver="this.style.color='yellow'" onMouseLeave="this.style.color='#fff'" href="#" style="color:white;text-decoration: none;font-weight: bold;" id="noti"><h4>This Month</h4></a></div></div>
			</div>

				</div>
				<!-- /.panel-heading -->
				<div class="panel-body">
					<div class="table-responsive">
					<?php 
							$this->load->view('common/errors');
					?>

			
						<form id="Tasklistform" name="Tasklistform" method="post">
                       
						<table class="table table-striped table-bordered table-hover" id="dataTables-example">
							<thead>
								<tr>
	<th>Target Completion</th><th>Task Title</th><th>Created On</th><th>Program</th><th>Assigned to</th><th>Status</th><th>Action</th>
								</tr>
							</thead>
							<tbody id="settasklist">
							    <?php
				                        
				                        foreach($tasklist as $value)
				                        {
				                            ?>
				                            <tr>
				                            <td><?= $value->end_date ?></td>
				                            <td><?= $value->title ?></td>
				                            
				                            <td><?= $value->created_at ?></td>
				                            <td><?= $value->pro_name ?></td>
				                            <td><?=$value->user_name ?></td>
				                        
				                            <td><?php

																switch ($value->status) {
																	case '0':
																		echo "Not Assigned";
																		break;
																		case '1':
																		echo "Assigned";
																		break;
																		case '2':
																		echo "Opened";
																		break;
																		case '3':
																		echo "Mark As Completed";
																		break;
																		case '4':
																		echo "Approved";
																		break;
																			case '5':
																		echo "Aborted";
																		break;	case '6':
																		echo "Rejected";
																		break;
																	
																}

															?></td>

<?php  if(!$is_assigned){ ?>
<td><a href="<?=  base_url().'/'.$value->link ?>" style="color:white;background-color:#323200;border-color: #323200" class="	btn btn-info">Open</a></td>
<?php } else {	?>
	         <td><button type="button" class="btn btn-primary btn-sm assign" tid="<?= $value->id ?>" style="background-color:#323200;color:white;border-color:#323200;" data-toggle="modal" data-target="#exampleModal">Assign</button></td>
	<?php } ?>
	</tr>
				                            
				                            <?php
				                        }
								
										?>
										
										
                            </tbody>
						</table>
						
						
				
						<?php if(isset($userdata['links'])){echo $userdata['links'];}?>
						<div id="#task_reassigning_model" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
							<div class="modal-dialog modal-sm">
    							<div class="modal-content">
									<div class="modal-header">
        								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        								<h4 class="modal-title">Task Discussion</h4>
      								</div>
      								<div class="modal-body">	
      								</div>
									<div class="modal-footer">
										<div class="input-group">
											<input id="task_id" name="task_id" type="hidden" value="">
											<input id="comment" name="comment" type="text" class="form-control input-sm" placeholder="Type your comment here..." />
											<span class="input-group-btn">
												<button id="send" name="send" type="submit" class="btn btn-warning btn-sm" id="btn-chat">
												Send
												</button>
											</span>
										</div>
      								</div>
	    						</div>
  							</div>
						</div>
						<div id="task_discussion_model" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
							<div class="modal-dialog modal-sm">
    							<div class="modal-content">
									<div class="modal-header">
        								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        								<h4 class="modal-title">Task Discussion</h4>
      								</div>
      								<div class="modal-body">	
      								</div>
									<div class="modal-footer">
										<div class="input-group">
											<input id="task_id" name="task_id" type="hidden" value="">
											<input id="comment" name="comment" type="text" class="form-control input-sm" placeholder="Type your comment here..." />
											<span class="input-group-btn">
												<button id="send" name="send" type="submit" class="btn btn-warning btn-sm" id="btn-chat">
												Send
												</button>
											</span>
										</div>
      								</div>
	    						</div>
  							</div>
						</div>
						</form>
					</div>
				</div>
				<!-- /.panel-body -->
			</div>
			<!-- /.panel -->
		</div>
		<!-- /.col-lg-12 -->
	</div>
</div>
<!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->

		
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="color:white;background-color:#323200;border-color:#323200">
        <h5 class="modal-title" id="heading">AS Aspian Hospital</h5>
        <button type="button" style="background-color:white;" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
                
                <form class="form-group" method="POST" action="<?= base_url('haspatal_registers/assigned_task') ?>">
                    <input type="hidden" name="id" id="tid">
                    <div class="form-group">
                        <label>Members</label>
                        <select class="form-control" name="member">
                            <option value="">Select Member</option>
                            <?php
                                
                                foreach($members as $value){
                                    ?>
                                    <option value="<?= $value->id ?>"><?= $value->first_name.'  '.$value->last_name.'  '.$value->contact_no ?></option>
                                    <?php
                                }
                            
                            ?>
                        </select>
                        <div class="form-group">
                            <label>Priority</label>
                            <select class="form-control" name="priority">
                                <option value="1">Low</option>
                                <option value="2">Medium</option>
                                <option value="3">High</option>
                                <option value="4">Urgent</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Remarks</label>
                            <textarea class="form-control" name="remark"></textarea>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Submit" class="btn btn-info" style="color:white;background-color:#323200;border-color:#323200">
                        </div>
                    </div>
                </form>
          
      </div>
      
    </div>
  </div>
</div>