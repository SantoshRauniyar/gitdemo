<?php


$ar=$this->session->userdata('task1');
print_r($ar);