
<div style="padding:2%;">
	<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">Business Registrants List</h1>
		</div>
		<!-- /.col-lg-12 -->
	</div>
	<!-- /.row -->
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">gfdghdh
				<div class="panel-heading" style="background-color:#ef0f0f;border-color:#ef0f0f;color:white;">
					<strong>Business Registrants </strong>
				</div>
				<!-- /.panel-heading -->
				<div class="panel-body" >
					<div class="table-responsive">
						<?php 
							$this->load->view('common/errors');
							if ($this->session->userdata('failedcountry')) {
								echo "Replies not available!!";
							}
						?>
									<h3>	<b><?= isset($heading)?$heading:"" ?></b></h3>
								Total Business Register	<?= $sr=count($business) ?>
						<form id="Grouplistform" name="Grouplistform" method="post" >
                       

						<table class="table table-striped table-bordered table-hover" id="dataTables-example">
							<thead>
								<tr>
									<th>Sr.</th>
									<th>Registration Time</th>
									<th>Business Name</th>
									<?php if($this->session->userdata('id')==102){ ?>	<th>Mobile</th><th>Email</th><th>Business Type</th><th>Action</th> <?php  } ?>
								<?php if($this->session->userdata('id')!=102){ ?>
									<th>State </th>
									
									<th>City </th>
									<th>Pincode</th>
									<?php } ?>
								</tr>
							</thead>
							<tbody>
				
								<tr class="odd gradeA">
									<?php
										//$sr=1;
										foreach($business as $data) {
													
													?>

										<tr>
										<td><?=$sr-- ?></td>
										<td><?=  $data->created_at ?></td>
										<td><?= $data->b_name ?></td>
									<?php if($this->session->userdata('id')==102){ ?>	<td><a href="tel:<?= $data->mobile ?>"><?= $data->mobile ?></a></td>
									<td><a href="mailto:<?= $data->mobile ?>"><?= $data->email ?></a></td> 
									<td>
									    <?php  
									    
									    switch($data->b_type)
									    {
									        case 11:
									            echo'<strong>Pharmacy</strong>';
									            break;
									            case 13:
									            echo'<strong>Imagings</strong>';
									            break;
									            case 16:
									            echo'<strong>Therapy</strong>';
									            break;
									            case 17:
									            echo'<strong>Counseling</strong>';
									            break;
									            case 14:
									            echo'<strong>Home Care</strong>';
									            break;
									            case 12:
									            echo'<strong>Lab</strong>';
									            break;
									            default:
									                echo'<strong>Business not selected</strong>';
									    }
									    
									    ?>
									    
									</td>
									<td><a class="btn btn-info" href="<?= base_url('dashboard/support_ticket/').'/'.$data->b_type.'/'.$data->id?>" style="background-color:#ef0f0f;color:white;border-color:#ef0f0f">Ticket</a></td>
									<?php } ?>
									
														<?php if($this->session->userdata('id')!=102){ ?>
										<td><?=  $data->state ?></td>
											<td><?=  $data->city ?></td>

										<td><?= $data->pincode ?></td>
																	<?php } ?>	
																</tr>

													<?php
												
												}


									?>
								</tr>
								
						
                            </tbody>
						</table>
					
						</form>
					</div>
				</div>
				<!-- /.panel-body -->
			</div>
			<!-- /.panel -->
		</div>
		<!-- /.col-lg-12 -->
	</div>
</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->