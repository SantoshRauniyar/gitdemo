<div class="site-footer">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<span>Copyright &copy; 2014 <a href="<?php echo base_url();?>" style="color:#FF6600;text-decoration:none;">KIZAKU.</a> All Rights Reserved</span>
			</div> <!-- /.col-md-6 -->
			<div class="col-md-6 col-sm-6">
				<ul class="social">
					<li><a href="#" class="fa fa-facebook"></a></li>
					<li><a href="#" class="fa fa-twitter"></a></li>
					<li><a href="#" class="fa fa-instagram"></a></li>
					<li><a href="#" class="fa fa-linkedin"></a></li>
					<li><a href="#" class="fa fa-rss"></a></li>
				</ul>
			</div> <!-- /.col-md-6 -->
		</div> <!-- /.row -->
	</div> <!-- /.container -->
</div> <!-- /.site-footer -->
   
